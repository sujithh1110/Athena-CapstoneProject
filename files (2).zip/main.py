"""
Athena backend — FastAPI scaffold.

This mirrors the logic already prototyped client-side in athena.html.
Swap the ANALYZE_* functions to call a real LLM (OpenAI-compatible or
local model) once you're ready; the routes and schemas won't need to change.

Run locally:
    pip install -r requirements.txt
    uvicorn main:app --reload

Run with Docker:
    docker compose up --build
"""
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from typing import Optional
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os

from models import Base, Student, Resume, Certificate, DSALog

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://athena:athena@db:5432/athena")
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)
Base.metadata.create_all(engine)

app = FastAPI(title="Athena API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten before production
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------- schemas ----------
class SignupIn(BaseModel):
    name: str
    email: str
    password: str
    track: str  # sde | web | data


class ResumeIn(BaseModel):
    student_id: int
    text: str


class GithubIn(BaseModel):
    student_id: int
    username: str


class DSALogIn(BaseModel):
    student_id: int
    topic: str
    count: int


# ---------- auth (stub — replace with real hashing + JWT) ----------
@app.post("/auth/signup")
def signup(payload: SignupIn, db=Depends(get_db)):
    existing = db.query(Student).filter(Student.email == payload.email).first()
    if existing:
        raise HTTPException(400, "Email already registered")
    student = Student(name=payload.name, email=payload.email, track=payload.track)
    db.add(student)
    db.commit()
    db.refresh(student)
    send_welcome_email(payload.name, payload.email)
    return {"id": student.id, "name": student.name, "track": student.track}


def send_welcome_email(name: str, email: str):
    """
    Real SMTP send — works with Gmail (use an App Password, not your normal
    password), SendGrid's SMTP relay, Mailgun, etc. Set these env vars:
        SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM
    If they're not set, this logs instead of sending, so signup never breaks
    just because email isn't configured yet.
    """
    import smtplib
    from email.mime.text import MIMEText

    host = os.getenv("SMTP_HOST")
    if not host:
        print(f"[email skipped — SMTP not configured] Would welcome {name} <{email}>")
        return

    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER")
    password = os.getenv("SMTP_PASSWORD")
    sender = os.getenv("SMTP_FROM", user)

    msg = MIMEText(
        f"Hi {name},\n\nThanks for registering with Athena. Your placement "
        "readiness dashboard is ready — sign in to upload your resume, "
        "connect GitHub, and start your first mock interview.\n\n— Athena"
    )
    msg["Subject"] = "Thanks for registering with Athena"
    msg["From"] = sender
    msg["To"] = email

    try:
        with smtplib.SMTP(host, port) as server:
            server.starttls()
            server.login(user, password)
            server.sendmail(sender, [email], msg.as_string())
    except Exception as e:
        # Don't fail signup just because mail delivery failed — log and move on.
        print(f"[email send failed] {e}")


@app.post("/auth/login")
def login(email: str, password: str, db=Depends(get_db)):
    # TODO: real password hashing (passlib) + JWT issuance
    student = db.query(Student).filter(Student.email == email).first()
    if not student:
        raise HTTPException(401, "Invalid credentials")
    return {"access_token": f"demo-token-{student.id}", "token_type": "bearer"}


# ---------- resume analysis ----------
@app.post("/resume/analyze")
def analyze_resume(payload: ResumeIn, db=Depends(get_db)):
    result = ANALYZE_RESUME(payload.text)
    record = Resume(student_id=payload.student_id, text=payload.text, score=result["score"])
    db.add(record)
    db.commit()
    return result


def ANALYZE_RESUME(text: str) -> dict:
    """
    Heuristic version — mirrors the client-side logic in athena.html.
    Replace the body with an LLM call for richer, more nuanced feedback:

        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1000,
            messages=[{"role": "user", "content": f"Analyze this resume: {text}"}],
        )
    """
    taxonomy = ["python", "java", "javascript", "react", "sql", "aws", "docker",
                "data structures", "algorithms", "machine learning"]
    lower = text.lower()
    found = [s for s in taxonomy if s in lower]
    verbs = sum(1 for v in ["built", "led", "designed", "optimized", "developed"] if v in lower)
    score = min(100, len(found) * 8 + verbs * 6)
    return {"score": score, "skills_found": found, "action_verbs_used": verbs}


# ---------- github analysis ----------
@app.post("/github/analyze")
def analyze_github(payload: GithubIn):
    """
    In production, call the GitHub REST API server-side (with a token for
    higher rate limits) instead of relying on the client's unauthenticated
    60 req/hour limit used in the prototype.
    """
    import httpx
    try:
        with httpx.Client(timeout=10) as client:
            user = client.get(f"https://api.github.com/users/{payload.username}")
            if user.status_code == 404:
                raise HTTPException(404, "GitHub user not found")
            repos = client.get(f"https://api.github.com/users/{payload.username}/repos?per_page=100")
    except httpx.RequestError:
        raise HTTPException(502, "Could not reach GitHub")

    repos_json = repos.json() if repos.status_code == 200 else []
    languages = {}
    stars = 0
    for r in repos_json:
        if r.get("language"):
            languages[r["language"]] = languages.get(r["language"], 0) + 1
        stars += r.get("stargazers_count", 0)

    score = min(100, len(repos_json) * 4 + stars * 2 + len(languages) * 5)
    return {"score": score, "repo_count": len(repos_json), "languages": languages, "stars": stars}


# ---------- DSA tracker ----------
@app.post("/dsa/log")
def log_dsa(payload: DSALogIn, db=Depends(get_db)):
    entry = DSALog(student_id=payload.student_id, topic=payload.topic, count=payload.count)
    db.add(entry)
    db.commit()
    return {"ok": True}


@app.get("/dsa/summary/{student_id}")
def dsa_summary(student_id: int, db=Depends(get_db)):
    logs = db.query(DSALog).filter(DSALog.student_id == student_id).all()
    return {"total": sum(l.count for l in logs), "by_topic": {l.topic: l.count for l in logs}}


@app.get("/health")
def health():
    return {"status": "ok"}
