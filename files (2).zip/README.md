# Athena — AI Career Intelligence & Placement Assistant

Two deliverables, built to plug into each other:

## 1. `athena.html` — working prototype (open it right now)
A single-file, fully interactive app — open it in any browser, on any device.
No install needed. It's your whole product surface end-to-end with **real
client-side logic**, not placeholder numbers:

- Mock login → profile → track selection (SDE / Web / Data)
- Resume analyzer — paste resume text, get a real keyword/structure/action-verb
  score against a skill taxonomy, plus rewrite suggestions
- GitHub analyzer — fetches your **actual public GitHub data** live via the
  GitHub REST API (repos, languages, stars, recent activity)
- DSA tracker with per-topic counters against a track-specific target
- Auto-generated learning roadmap from your live skill/DSA gaps
- Mock interview with rule-based feedback (keyword coverage, filler words, STAR structure)
- Certificate manager
- Company eligibility checker against sample hiring bars
- The "Aegis" radar — a shield-shaped live readiness chart aggregating every panel

Everything lives in one `state` object at the top of the `<script>` tag, so
it's easy to read and extend. State resets on refresh (in-memory only — no
`localStorage`, since that isn't reliable in every embedding context. Swap
it for `localStorage` or the real backend below when you deploy it).

## 2. `athena-backend/` — production scaffold
When you're ready to make this a real, persistent, multi-user app matching
your original tech stack:

```
athena-backend/
  main.py            FastAPI app: auth, resume/github analysis, DSA logging
  models.py          SQLAlchemy models (Student, Resume, Certificate, DSALog)
  requirements.txt    Python deps, including sentence-transformers for semantic search
  Dockerfile
  docker-compose.yml  Spins up Postgres + the API together
```

Run it:
```bash
cd athena-backend
docker compose up --build
# API live at http://localhost:8000, docs at /docs
```

### Where the "AI" plugs in
`ANALYZE_RESUME()` in `main.py` currently runs the same heuristic scoring as
the HTML prototype — deterministic and free to run. When you want real LLM
reasoning (nuanced feedback, tailored roadmap text, generated interview
questions), replace that function's body with a call to an OpenAI-compatible
endpoint or a local model, and keep the route signature the same so the
frontend never has to change.

### Sending real confirmation emails
Two working paths, already wired in:
- **`athena.html` (client-only)**: uses EmailJS so it can send mail with no
  backend at all. Create a free account at emailjs.com, add an Email Service
  and a template with `{{to_name}}`/`{{to_email}}` variables, then fill in
  `EMAILJS_CONFIG` near the top of the `<script>` tag. Until you do, signup
  still works — the UI just says honestly that email isn't configured yet.
- **`athena-backend/main.py`**: `send_welcome_email()` uses real SMTP
  (`smtplib`). Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`,
  `SMTP_FROM` as environment variables (Gmail App Password, SendGrid SMTP
  relay, Mailgun, etc. all work) and it sends on every `/auth/signup` call.

### Suggested next steps to make this genuinely yours
- Replace the `demo-token` login with real password hashing (`passlib`) + JWT
- Connect `athena.html`'s `fetch()` calls to `http://localhost:8000` instead
  of computing scores in-browser, once the backend is running
- Add a PDF-to-text step (e.g. `pdfplumber`) so resume upload doesn't require
  copy-pasting text
- Move the skill taxonomy, company list, and interview question bank into
  the database so non-engineers can update them without touching code
- Add Sentence Transformers–based semantic matching (already in
  `requirements.txt`) so resume-skill matching isn't limited to exact keyword
  hits — this is the natural place to use it, per your original tech stack

Both pieces are intentionally readable rather than clever — everything is in
plain functions with comments at the exact spots you'd want to customize.
