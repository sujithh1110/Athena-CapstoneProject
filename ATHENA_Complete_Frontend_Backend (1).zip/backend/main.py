"""ATHENA FastAPI backend.

Run from this directory:
    python -m venv .venv
    # Windows: .venv\\Scripts\\activate
    pip install -r requirements.txt
    uvicorn main:app --reload
"""
import hashlib
import hmac
import os
import secrets
from typing import Generator

import httpx
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from models import Base, Certificate, DSALog, Resume, Student

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://athena:athena@localhost:5432/athena",
)
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

app = FastAPI(title="ATHENA API", version="1.0.0")
allowed_origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "http://localhost:8080,http://127.0.0.1:8080,http://localhost:5500").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)

# Create tables for this starter project. For production, use Alembic migrations.
@app.on_event("startup")
def create_tables() -> None:
    Base.metadata.create_all(bind=engine)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# PBKDF2 is provided by Python's standard library; no extra password package required.
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000)
    return f"pbkdf2_sha256$310000${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, rounds, salt_hex, digest_hex = stored.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        candidate = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(rounds)
        ).hex()
        return hmac.compare_digest(candidate, digest_hex)
    except (ValueError, TypeError):
        return False


class SignupIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: str = Field(min_length=5, max_length=255)
    password: str = Field(min_length=8, max_length=128)
    track: str = Field(default="sde", pattern="^(sde|web|data)$")


class LoginIn(BaseModel):
    email: str
    password: str


class ResumeIn(BaseModel):
    student_id: int
    text: str = Field(min_length=1)


class GithubIn(BaseModel):
    student_id: int
    username: str = Field(min_length=1, max_length=39)


class DSALogIn(BaseModel):
    student_id: int
    topic: str = Field(min_length=1, max_length=100)
    count: int = Field(ge=0, le=10000)


def send_welcome_email(name: str, email: str) -> None:
    """Send email only when SMTP settings are configured; otherwise skip safely."""
    host = os.getenv("SMTP_HOST")
    if not host:
        print(f"[email skipped — SMTP not configured] Would welcome {name} <{email}>")
        return

    import smtplib
    from email.mime.text import MIMEText

    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER", "")
    password = os.getenv("SMTP_PASSWORD", "")
    sender = os.getenv("SMTP_FROM", user)
    msg = MIMEText(
        f"Hi {name},\n\nThanks for registering with ATHENA. Your placement readiness dashboard is ready.\n\n— ATHENA"
    )
    msg["Subject"] = "Welcome to ATHENA"
    msg["From"] = sender
    msg["To"] = email
    try:
        with smtplib.SMTP(host, port, timeout=15) as server:
            server.starttls()
            if user:
                server.login(user, password)
            server.sendmail(sender, [email], msg.as_string())
    except Exception as exc:
        # Email failure must not undo a successful account registration.
        print(f"[email send failed] {exc}")


@app.post("/auth/signup")
def signup(payload: SignupIn, db: Session = Depends(get_db)):
    email = payload.email.strip().lower()
    existing = db.query(Student).filter(Student.email == email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    student = Student(
        name=payload.name.strip(),
        email=email,
        password_hash=hash_password(payload.password),
        track=payload.track,
    )
    db.add(student)
    db.commit()
    db.refresh(student)
    send_welcome_email(student.name, student.email)
    return {"id": student.id, "name": student.name, "track": student.track}


@app.post("/auth/login")
def login(payload: LoginIn, db: Session = Depends(get_db)):
    email = payload.email.strip().lower()
    student = db.query(Student).filter(Student.email == email).first()
    if not student or not verify_password(payload.password, student.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    # This is a development session token, not a signed JWT. Add JWT auth before deployment.
    return {"access_token": f"dev-token-{student.id}", "token_type": "bearer", "student_id": student.id}


def analyze_resume_text(text: str) -> dict:
    taxonomy = [
        "python", "java", "javascript", "react", "sql", "aws", "docker",
        "data structures", "algorithms", "machine learning",
    ]
    lower = text.lower()
    found = [skill for skill in taxonomy if skill in lower]
    verbs = sum(1 for verb in ["built", "led", "designed", "optimized", "developed"] if verb in lower)
    score = min(100, len(found) * 8 + verbs * 6)
    return {"score": score, "skills_found": found, "action_verbs_used": verbs}


@app.post("/resume/analyze")
def analyze_resume(payload: ResumeIn, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.id == payload.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    result = analyze_resume_text(payload.text)
    record = Resume(student_id=payload.student_id, text=payload.text, score=result["score"])
    db.add(record)
    db.commit()
    return result


@app.post("/github/analyze")
def analyze_github(payload: GithubIn):
    try:
        with httpx.Client(timeout=10, follow_redirects=True) as client:
            user_response = client.get(f"https://api.github.com/users/{payload.username}")
            if user_response.status_code == 404:
                raise HTTPException(status_code=404, detail="GitHub user not found")
            user_response.raise_for_status()
            repos_response = client.get(
                f"https://api.github.com/users/{payload.username}/repos",
                params={"per_page": 100, "sort": "updated"},
            )
            repos_response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail="GitHub API returned an error") from exc
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail="Could not reach GitHub") from exc

    repos = repos_response.json()
    languages: dict[str, int] = {}
    stars = 0
    for repo in repos:
        if repo.get("language"):
            languages[repo["language"]] = languages.get(repo["language"], 0) + 1
        stars += repo.get("stargazers_count", 0)
    score = min(100, len(repos) * 4 + stars * 2 + len(languages) * 5)
    return {"score": score, "repo_count": len(repos), "languages": languages, "stars": stars}


@app.post("/dsa/log")
def log_dsa(payload: DSALogIn, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.id == payload.student_id).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    entry = db.query(DSALog).filter(
        DSALog.student_id == payload.student_id,
        DSALog.topic == payload.topic,
    ).first()
    if entry:
        entry.count = payload.count
    else:
        db.add(DSALog(student_id=payload.student_id, topic=payload.topic, count=payload.count))
    db.commit()
    return {"ok": True}


@app.get("/dsa/summary/{student_id}")
def dsa_summary(student_id: int, db: Session = Depends(get_db)):
    logs = db.query(DSALog).filter(DSALog.student_id == student_id).all()
    return {"total": sum(log.count for log in logs), "by_topic": {log.topic: log.count for log in logs}}


@app.get("/health")
def health():
    return {"status": "ok"}
