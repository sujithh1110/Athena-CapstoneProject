/* =========================================================
   ATHENA — client-side placement intelligence engine
   Single-file prototype: all "AI analysis" below runs as
   real, inspectable heuristics (keyword/structure scoring),
   not randomized numbers. Swap ANALYZE_* functions for real
   LLM/API calls once the FastAPI backend is wired up.
   ========================================================= */

const TAXONOMY = {
  "Languages": ["python","java","c++","javascript","typescript","c ","golang","go","sql","kotlin","rust"],
  "Web": ["react","node.js","node","express","html","css","django","flask","fastapi","rest api","next.js","tailwind"],
  "Data/ML": ["pandas","numpy","machine learning","deep learning","tensorflow","pytorch","scikit","nlp","data analysis","llm"],
  "Cloud/DevOps": ["aws","azure","gcp","docker","kubernetes","git","github","ci/cd","linux","jenkins"],
  "CS Core": ["data structures","algorithms","oop","dbms","operating system","operating systems","computer networks","system design"]
};
const ACTION_VERBS = ["led","built","developed","designed","implemented","optimized","improved","created","achieved","automated","launched","architected","reduced","increased","deployed","engineered"];
const RESUME_SECTIONS = ["education","experience","project","skill","certification","achievement"];

const TRACKS = {
  sde: { label:"Software Development (SDE)", req:["python","java","c++","data structures","algorithms","system design","git"], dsaTarget:220, minRepos:4 },
  web: { label:"Web / Full-Stack", req:["javascript","react","node.js","html","css","rest api","git"], dsaTarget:140, minRepos:5 },
  data: { label:"Data / ML", req:["python","pandas","numpy","machine learning","sql","data analysis"], dsaTarget:120, minRepos:3 }
};

const DSA_TOPICS = ["Arrays & Strings","Linked List","Trees & BST","Graphs","Dynamic Programming","Sorting/Searching","Stacks/Queues","Recursion/Backtracking"];



const COMPANIES = [
  {name:"NimbusWorks", tier:"Product", minCGPA:7.0, minDSA:80, minPRI:55, backlogsOK:0, skillsAny:["python","java","data structures"]},
  {name:"Vantara Systems", tier:"Service", minCGPA:6.0, minDSA:30, minPRI:35, backlogsOK:1, skillsAny:["java","sql","c++"]},
  {name:"Loombridge Analytics", tier:"Data", minCGPA:7.0, minDSA:50, minPRI:45, backlogsOK:0, skillsAny:["python","sql","pandas","machine learning"]},
  {name:"Kestrel Cloud", tier:"Product", minCGPA:7.5, minDSA:150, minPRI:65, backlogsOK:0, skillsAny:["system design","aws","docker"]},
  {name:"Bramwell Tech (Mass Hire)", tier:"Service", minCGPA:5.5, minDSA:15, minPRI:25, backlogsOK:2, skillsAny:["java","python","javascript"]}
];

/* ---------------- persistence (works inside the claude.ai artifact frame;
   falls back to an in-memory session store if window.storage isn't present,
   e.g. when this file is opened directly from disk) ---------------- */
const memoryStore = {};
async function storeGet(key){
  try{
    if(window.storage){ const r = await window.storage.get(key, false); return r ? JSON.parse(r.value) : null; }
  }catch(e){ return null; }
  return memoryStore[key] ? JSON.parse(memoryStore[key]) : null;
}
async function storeSet(key, value){
  try{
    if(window.storage){ await window.storage.set(key, JSON.stringify(value), false); return; }
  }catch(e){}
  memoryStore[key] = JSON.stringify(value);
}
// Not real cryptography — a simple non-reversible-looking digest so plaintext
// passwords aren't literally sitting in storage in this prototype. Replace
// with proper hashing (bcrypt/argon2) server-side in the FastAPI backend.
function pseudoHash(str){
  let h = 0;
  for(let i=0;i<str.length;i++){ h = (Math.imul(31,h) + str.charCodeAt(i))|0; }
  return "h" + Math.abs(h).toString(36) + str.length;
}

/* ---------------- state ---------------- */
let state = {
  user:null,
  track:"sde",
  cgpa:7.5,
  backlogs:0,
  resume:{text:"", analyzed:false, score:0, found:[], gaps:[], sections:{}, verbs:0, metrics:0, words:0, suggestions:[]},
  github:{username:"", loaded:false, error:"", score:0, data:null},
  dsa:{}, // topic -> count
  certs:[], // {name, issuer, date, category}
  interview:{session:[], loading:false, error:"", score:0}
};
DSA_TOPICS.forEach(t=>state.dsa[t]=0);

/* ---------------- outbound email (EmailJS — sends straight from the
   browser, no backend needed) -----------------------------------------
   To make this actually deliver mail:
     1. Create a free account at https://www.emailjs.com
     2. Add an Email Service (e.g. connect Gmail) and copy its Service ID
     3. Create an Email Template with variables {{to_name}} and {{to_email}}
        (subject e.g. "Welcome to Athena, {{to_name}}") and copy its Template ID
     4. Copy your Public Key from Account > API Keys
     5. Paste all three below. Until then, sending fails gracefully and the
        UI says so honestly instead of pretending mail went out. ---------- */
const EMAILJS_CONFIG = { serviceId:"YOUR_SERVICE_ID", templateId:"YOUR_TEMPLATE_ID", publicKey:"YOUR_PUBLIC_KEY" };
let emailjsReady = false;
try{
  if(EMAILJS_CONFIG.publicKey !== "YOUR_PUBLIC_KEY" && window.emailjs){ emailjs.init(EMAILJS_CONFIG.publicKey); emailjsReady = true; }
}catch(e){}
async function sendWelcomeEmail(name, email){
  if(!emailjsReady) throw new Error("Email isn't configured yet — add your EmailJS keys in the code (see comment above EMAILJS_CONFIG).");
  await emailjs.send(EMAILJS_CONFIG.serviceId, EMAILJS_CONFIG.templateId, { to_name:name, to_email:email });
}

/* ---------------- auth screen ---------------- */
let authMode = "signin"; // "signin" | "signup" | "welcome"
let authError = "";
let signupTrack = "sde";
let pendingUser = null;
let welcomeEmailState = "sending"; // sending | sent | failed
let welcomeEmailError = "";

function renderAuth(){
  if(authMode === "welcome"){
    document.getElementById("authFormWrap").innerHTML = `
      <div class="auth-title serif">You're in, ${pendingUser.name.split(" ")[0]}</div>
      <div class="auth-success">
        ${welcomeEmailState==="sending" ? `Sending a confirmation to <b style="color:var(--text-hi)">${pendingUser.email}</b>…` : ""}
        ${welcomeEmailState==="sent" ? `A "Thank you for registering" email is on its way to <b style="color:var(--text-hi)">${pendingUser.email}</b>.` : ""}
        ${welcomeEmailState==="failed" ? `Couldn't send the confirmation email: ${welcomeEmailError}` : ""}
      </div>
      <button class="btn btn-primary btn-full" style="margin-top:18px;" onclick="enterApp(pendingUser)">Continue to Athena</button>
    `;
    return;
  }
  const isSignup = authMode === "signup";
  document.getElementById("authFormWrap").innerHTML = `
    <div class="auth-title serif">${isSignup ? "Create your account" : "Welcome back"}</div>
    ${isSignup ? `<div class="field"><label>Full name</label><input class="uline" id="inName"></div>` : ``}
    <div class="field"><label>Email</label><input class="uline" id="inEmail" type="email"></div>
    ${isSignup ? `
    <div class="field"><label>Target track</label>
      <div class="track-pills" id="trackPills">
        <button type="button" class="tpill ${signupTrack==='sde'?'active':''}" onclick="setSignupTrack('sde')">SDE</button>
        <button type="button" class="tpill ${signupTrack==='web'?'active':''}" onclick="setSignupTrack('web')">Web / Full-Stack</button>
        <button type="button" class="tpill ${signupTrack==='data'?'active':''}" onclick="setSignupTrack('data')">Data / ML</button>
      </div>
    </div>` : ``}
    <div class="field"><label>Password</label><input class="uline" id="inPass" type="password"></div>
    <button class="btn btn-primary btn-full" style="margin-top:8px;" onclick="${isSignup ? 'doSignUp()' : 'doSignIn()'}">${isSignup ? "Create account" : "Sign in"}</button>
    ${authError ? `<div class="err">${authError}</div>` : ""}
    <div style="text-align:center; margin-top:20px; font-size:12.5px; color:var(--text-mid);">
      ${isSignup ? "Already have an account?" : "No account yet?"}
      <a href="javascript:void(0)" onclick="authError=''; authMode='${isSignup?'signin':'signup'}'; renderAuth();">${isSignup ? "Sign in" : "Create one"}</a>
    </div>
  `;
}
function setSignupTrack(t){ signupTrack = t; renderAuth(); }

async function doSignUp(){
  const name = document.getElementById("inName").value.trim();
  const email = document.getElementById("inEmail").value.trim().toLowerCase();
  const track = signupTrack;
  const pass = document.getElementById("inPass").value;
  if(!name || !email || !pass){ authError = "Fill in your name, email, and password."; renderAuth(); return; }
  if(pass.length < 6){ authError = "Password must be at least 6 characters."; renderAuth(); return; }
  const users = (await storeGet("athena_users")) || [];
  if(users.some(u=>u.email===email)){ authError = "An account with that email already exists."; renderAuth(); return; }
  users.push({name, email, track, passHash: pseudoHash(pass)});
  await storeSet("athena_users", users);
  authError = "";
  pendingUser = {name, email, track};
  authMode = "welcome";
  welcomeEmailState = "sending";
  renderAuth();
  try{
    await sendWelcomeEmail(name, email);
    welcomeEmailState = "sent";
  }catch(e){
    welcomeEmailState = "failed";
    welcomeEmailError = e.message;
  }
  if(authMode==="welcome") renderAuth();
}

async function doSignIn(){
  const email = document.getElementById("inEmail").value.trim().toLowerCase();
  const pass = document.getElementById("inPass").value;
  if(!email || !pass){ authError = "Enter your email and password."; renderAuth(); return; }
  const users = (await storeGet("athena_users")) || [];
  const match = users.find(u=>u.email===email);
  if(!match){ authError = "No account found with that email. Create one first."; renderAuth(); return; }
  if(match.passHash !== pseudoHash(pass)){ authError = "Incorrect password."; renderAuth(); return; }
  authError = "";
  enterApp(match);
}

function enterApp(user){
  state.user = {name:user.name, email:user.email};
  state.track = user.track;
  document.getElementById("authScreen").style.display="none";
  document.getElementById("appShell").classList.add("active");
  document.getElementById("sideWho").textContent = user.name;
  document.getElementById("sideTrack").textContent = TRACKS[user.track].label;
  renderNav();
  goTo("overview");
}

function signOut(){
  document.getElementById("appShell").classList.remove("active");
  document.getElementById("authScreen").style.display="grid";
  authMode = "signin"; authError = "";
  renderAuth();
}

/* ---------------- nav ---------------- */
const PAGES = [
  {id:"overview", label:"Overview", ico:"◆"},
  {id:"resume", label:"Resume", ico:"▤"},
  {id:"github", label:"GitHub", ico:"◧"},
  {id:"dsa", label:"DSA Tracker", ico:"▦"},
  {id:"roadmap", label:"Roadmap", ico:"➤"},
  {id:"interview", label:"Mock Interview", ico:"◍"},
  {id:"certs", label:"Certificates", ico:"◈"},
  {id:"eligibility", label:"Eligibility", ico:"▣"}
];
let current = "overview";
function renderNav(){
  document.getElementById("navlist").innerHTML = PAGES.map(p=>`
    <li><button class="navbtn ${p.id===current?'active':''}" onclick="goTo('${p.id}')">
      <span class="ico">${p.ico}</span>${p.label}
    </button></li>`).join("");
}
function goTo(id){
  current = id;
  renderNav();
  const fn = {overview:renderOverview, resume:renderResume, github:renderGithub, dsa:renderDSA, roadmap:renderRoadmap, interview:renderInterview, certs:renderCerts, eligibility:renderEligibility}[id];
  fn();
}

/* ---------------- scoring engine ---------------- */
function computeResumeScore(r){
  if(!r.analyzed) return 0;
  const sectionScore = Object.values(r.sections).filter(Boolean).length / RESUME_SECTIONS.length * 30;
  const skillScore = Math.min(r.found.length / 10, 1) * 30;
  const verbScore = Math.min(r.verbs / 6, 1) * 20;
  const metricScore = Math.min(r.metrics / 4, 1) * 20;
  return Math.round(sectionScore + skillScore + verbScore + metricScore);
}
function computeGithubScore(g){
  if(!g.loaded || !g.data) return 0;
  const d = g.data;
  const repoScore = Math.min(d.repoCount / 10, 1) * 40;
  const activityScore = Math.min(d.activeRepos / 4, 1) * 30;
  const starScore = Math.min(d.totalStars / 10, 1) * 15;
  const langScore = Math.min(d.languages.length / 4, 1) * 15;
  return Math.round(repoScore + activityScore + starScore + langScore);
}
function computeDSAScore(){
  const target = computeDynamicDSATarget();
  const total = Object.values(state.dsa).reduce((a,b)=>a+b,0);
  return Math.min(Math.round(total/target*100), 100);
}
function computeCertScore(){
  return Math.min(state.certs.length * 20, 100);
}
function computeProfileScore(){
  let pts = 0;
  if(state.resume.analyzed) pts += 34;
  if(state.github.loaded) pts += 33;
  if(state.certs.length>0) pts += 33;
  return pts;
}
function totalDSACount(){ return Object.values(state.dsa).reduce((a,b)=>a+b,0); }
function computePRI(){
  const r = computeResumeScore(state.resume);
  const g = computeGithubScore(state.github);
  const d = computeDSAScore();
  const iv = state.interview.score;
  const c = computeCertScore();
  const p = computeProfileScore();
  return Math.round(r*0.25 + g*0.20 + d*0.20 + iv*0.15 + c*0.10 + p*0.10);
}
function readinessLabel(score){
  if(score>=75) return {t:"Placement-ready", cls:"gold"};
  if(score>=50) return {t:"On track", cls:"teal"};
  if(score>=25) return {t:"Developing", cls:"coral"};
  return {t:"Just starting", cls:"coral"};
}

/* ---------------- Claude API helper (real model calls, no key needed) ---------------- */
async function callClaude(userContent, systemPrompt, maxTokens=1000){
  const body = { model:"claude-sonnet-4-6", max_tokens:maxTokens, messages:[{role:"user", content:userContent}] };
  if(systemPrompt) body.system = systemPrompt;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body)
  });
  if(!res.ok) throw new Error("AI request failed (" + res.status + ")");
  const data = await res.json();
  return (data.content || []).map(b => b.type === "text" ? b.text : "").join("\n").trim();
}
function extractJson(text){
  const cleaned = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{"); const end = cleaned.lastIndexOf("}");
  if(start === -1 || end === -1) throw new Error("No JSON in AI response");
  return JSON.parse(cleaned.slice(start, end+1));
}

/* ---------------- OVERVIEW ---------------- */
function renderOverview(){
  const pri = computePRI();
  const rl = readinessLabel(pri);
  const axes = [
    {k:"Resume", v:computeResumeScore(state.resume)},
    {k:"GitHub", v:computeGithubScore(state.github)},
    {k:"DSA", v:computeDSAScore()},
    {k:"Interview", v:state.interview.score},
    {k:"Certificates", v:computeCertScore()},
    {k:"Profile", v:computeProfileScore()}
  ];
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Command deck</div>
      <h1 class="serif">Welcome back, ${state.user.name.split(" ")[0]}</h1>
      <p>Track: <b style="color:var(--text-hi)">${TRACKS[state.track].label}</b>. This is your live placement-readiness index, aggregated from every panel in Athena.</p>
    </div>

    <div class="panel">
      <div class="hex-wrap">
        <div>${renderAegis(axes, pri)}</div>
        <div class="hex-legend">
          <div style="margin-bottom:6px;"><span class="badge ${rl.cls}">${rl.t}</span></div>
          <div style="font-size:34px; font-weight:700;" class="mono">${pri}<span style="font-size:16px; color:var(--text-mid);">/100</span></div>
          <div style="font-size:12px; color:var(--text-mid); margin-bottom:6px;">Placement Readiness Index</div>
          ${axes.map(a=>`<div class="row"><span>${a.k}</span><b>${a.v}</b></div>`).join("")}
        </div>
      </div>
    </div>

    <div class="grid3">
      <div class="panel stat"><div class="n mono">${totalDSACount()}</div><div class="l">DSA problems solved</div></div>
      <div class="panel stat"><div class="n mono">${state.resume.found.length}</div><div class="l">Skills detected</div></div>
      <div class="panel stat"><div class="n mono">${state.certs.length}</div><div class="l">Certificates logged</div></div>
    </div>

    <div class="panel">
      <h3>Where to focus next</h3>
      ${renderGapList()}
    </div>
  `;
}
function renderGapList(){
  const items = [];
  if(!state.resume.analyzed) items.push(["Analyze your resume", "resume", "No resume data yet — this is 25% of your score."]);
  if(!state.github.loaded) items.push(["Connect your GitHub", "github", "GitHub activity is 20% of your score."]);
  if(totalDSACount() < computeDynamicDSATarget()*0.3) items.push(["Log more DSA practice", "dsa", `You're well below your current personalized target of ${computeDynamicDSATarget()} problems.`]);
  if(state.interview.session.length===0) items.push(["Run a mock interview", "interview", "No interview attempts recorded yet."]);
  if(state.certs.length===0) items.push(["Add a certificate", "certs", "Even one relevant certificate lifts your profile score."]);
  if(items.length===0) return `<div class="empty">All panels have data. Check the Roadmap for deeper skill gaps.</div>`;
  return items.map(([t,pg,d])=>`
    <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid var(--line);">
      <div><div style="font-weight:500; font-size:13.5px;">${t}</div><div style="font-size:12px; color:var(--text-mid);">${d}</div></div>
      <button class="btn btn-sm" onclick="goTo('${pg}')">Open →</button>
    </div>`).join("");
}
function renderAegis(axes, pri){
  const cx=140, cy=140, R=110, n=axes.length;
  const angle = i => (Math.PI*2*i/n) - Math.PI/2;
  const pt = (i, r) => [cx + r*Math.cos(angle(i)), cy + r*Math.sin(angle(i))];
  const rings = [0.33,0.66,1].map(f=>{
    const pts = axes.map((_,i)=>pt(i, R*f).join(",")).join(" ");
    return `<polygon points="${pts}" fill="none" stroke="#2A3157" stroke-width="1"/>`;
  }).join("");
  const spokes = axes.map((_,i)=>{
    const [x,y] = pt(i,R);
    return `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="#2A3157" stroke-width="1"/>`;
  }).join("");
  const dataPts = axes.map((a,i)=>pt(i, R*(a.v/100)).join(",")).join(" ");
  const labels = axes.map((a,i)=>{
    const [x,y] = pt(i, R+22);
    return `<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle" font-size="10.5" fill="#9AA1C4" font-family="Inter">${a.k}</text>`;
  }).join("");
  return `<svg width="280" height="280" viewBox="0 0 280 280">
    ${rings}${spokes}
    <polygon points="${dataPts}" fill="rgba(203,161,53,0.22)" stroke="#CBA135" stroke-width="2"/>
    ${axes.map((a,i)=>{const [x,y]=pt(i,R*(a.v/100)); return `<circle cx="${x}" cy="${y}" r="3" fill="#CBA135"/>`}).join("")}
    ${labels}
    <text x="${cx}" y="${cy-4}" text-anchor="middle" font-size="24" font-weight="700" fill="#F1F0EA" font-family="JetBrains Mono">${pri}</text>
    <text x="${cx}" y="${cy+14}" text-anchor="middle" font-size="9.5" fill="#5D6389" font-family="Inter">READINESS</text>
  </svg>`;
}

/* ---------------- RESUME ---------------- */
function renderResume(){
  const r = state.resume;
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Resume intelligence</div>
      <h1 class="serif">Resume analysis</h1>
      <p>Paste your resume text below. Athena checks structure, skill coverage against your track, action-verb usage, and quantified impact — the same signals recruiters skim for in 30 seconds.</p>
    </div>
    <div class="panel">
      <label>Attach resume (PDF or .txt)</label>
      <div style="display:flex; gap:10px; align-items:center; margin-bottom:14px;">
        <input id="resumeFile" type="file" accept=".pdf,.txt" style="width:auto; flex:1;" onchange="handleResumeFile(event)">
        <span id="fileStatus" class="hint" style="margin:0;"></span>
      </div>
      <label>Resume text</label>
      <textarea id="resumeText" rows="10" placeholder="Attach a file above, or paste resume text directly...">${r.text}</textarea>
      <div style="margin-top:10px; display:flex; gap:10px;">
        <button class="btn btn-primary" onclick="analyzeResume()">Analyze resume</button>
      </div>
    </div>
    ${r.analyzed ? renderResumeResults() : `<div class="panel"><div class="empty">Run an analysis to see your score, skill coverage, and rewrite suggestions.</div></div>`}
  `;
}
async function handleResumeFile(evt){
  const file = evt.target.files[0];
  if(!file) return;
  const status = document.getElementById("fileStatus");
  status.textContent = "Reading " + file.name + "…";
  try{
    let text = "";
    if(file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")){
      pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
      const buf = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({data:buf}).promise;
      for(let p=1; p<=pdf.numPages; p++){
        const page = await pdf.getPage(p);
        const content = await page.getTextContent();
        text += content.items.map(it=>it.str).join(" ") + "\n";
      }
    } else {
      text = await file.text();
    }
    if(text.trim().length < 20){
      status.textContent = "Couldn't extract readable text from that file — try pasting it instead.";
      return;
    }
    document.getElementById("resumeText").value = text.trim();
    status.textContent = "Loaded " + file.name + " — " + text.trim().split(/\s+/).length + " words. Click Analyze.";
  }catch(e){
    status.textContent = "Couldn't read that file (" + e.message + "). Try pasting the text instead.";
  }
}
function analyzeResume(){
  const text = document.getElementById("resumeText").value;
  if(text.trim().length < 30){ alert("Paste a bit more resume text — at least a few lines."); return; }
  const lower = text.toLowerCase();
  const found = [], gaps = [];
  Object.entries(TAXONOMY).forEach(([cat, skills])=>{
    skills.forEach(s=>{
      if(lower.includes(s.trim())) found.push(s.trim());
    });
  });
  const trackReq = TRACKS[state.track].req;
  trackReq.forEach(s=>{ if(!lower.includes(s)) gaps.push(s); });
  const sections = {};
  RESUME_SECTIONS.forEach(s=> sections[s] = lower.includes(s));
  const verbs = ACTION_VERBS.filter(v=>lower.includes(v)).length;
  const metrics = (text.match(/\d+%|\$\d+|\b\d{2,}\b|\d+x\b/g) || []).length;
  const words = text.trim().split(/\s+/).length;

  const suggestions = [];
  if(!sections.project) suggestions.push("Add a dedicated Projects section — recruiters weight this heavily for freshers.");
  if(verbs < 4) suggestions.push("Start more bullets with strong action verbs (built, designed, optimized) instead of \"responsible for\".");
  if(metrics < 3) suggestions.push("Quantify impact: add numbers like users served, % improvement, or time saved to at least 3 bullets.");
  if(words < 250) suggestions.push("Your resume looks thin — expand on 1–2 projects with technical depth.");
  if(words > 900) suggestions.push("Your resume is long for a fresher profile — trim to what fits one page.");
  if(gaps.length>0) suggestions.push(`Missing track-critical skills: ${gaps.slice(0,4).join(", ")}. Add real project experience with these, not just a skills list.`);
  if(!sections.certification) suggestions.push("Consider adding a Certifications line if you've completed any relevant courses.");

  state.resume = {text, analyzed:true, score:0, found:[...new Set(found)], gaps, sections, verbs, metrics, words, suggestions};
  renderResume();
}
function renderResumeResults(){
  const r = state.resume;
  const score = computeResumeScore(r);
  return `
    <div class="grid2">
      <div class="panel">
        <h3>Score breakdown</h3>
        <div class="stat" style="margin-bottom:12px;"><div class="n mono">${score}/100</div><div class="l">Resume score</div></div>
        <table>
          <tr><td>Sections present</td><td style="text-align:right;">${Object.values(r.sections).filter(Boolean).length}/${RESUME_SECTIONS.length}</td></tr>
          <tr><td>Skills detected</td><td style="text-align:right;">${r.found.length}</td></tr>
          <tr><td>Action verbs used</td><td style="text-align:right;">${r.verbs}</td></tr>
          <tr><td>Quantified bullets (approx)</td><td style="text-align:right;">${r.metrics}</td></tr>
          <tr><td>Word count</td><td style="text-align:right;">${r.words}</td></tr>
        </table>
      </div>
      <div class="panel">
        <h3>Skills detected vs track requirements</h3>
        <div class="taglist" style="margin-bottom:12px;">
          ${r.found.length ? r.found.map(s=>`<span class="tag found">${s}</span>`).join("") : `<span class="empty">None detected</span>`}
        </div>
        <div style="font-size:12px; color:var(--text-mid); margin-bottom:6px;">Missing for ${TRACKS[state.track].label}:</div>
        <div class="taglist">
          ${r.gaps.length ? r.gaps.map(s=>`<span class="tag gap">${s}</span>`).join("") : `<span class="ok">All track skills covered</span>`}
        </div>
      </div>
    </div>
    <div class="panel">
      <h3>Auto-generated improvement suggestions</h3>
      ${r.suggestions.map(s=>`<div style="padding:8px 0; border-bottom:1px solid var(--line); font-size:13.5px; color:var(--text-mid);">→ ${s}</div>`).join("") || `<div class="ok">Strong resume — no major gaps detected.</div>`}
    </div>
  `;
}

/* ---------------- GITHUB ---------------- */
function renderGithub(){
  const g = state.github;
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Repository intelligence</div>
      <h1 class="serif">GitHub analysis</h1>
      <p>Pulls your public profile straight from the GitHub REST API in your browser — no server involved. Works for any public username.</p>
    </div>
    <div class="panel">
      <label>GitHub username</label>
      <div style="display:flex; gap:10px;">
        <input id="ghUser" value="${g.username}" placeholder="octocat" style="flex:1;">
        <button class="btn btn-primary" onclick="analyzeGithub()">Fetch & analyze</button>
      </div>
      ${g.error ? `<div class="err">${g.error}</div>` : ""}
    </div>
    ${g.loaded ? renderGithubResults() : `<div class="panel"><div class="empty">Enter a username to pull repo count, languages, stars, and recent activity.</div></div>`}
  `;
}
async function analyzeGithub(){
  const username = document.getElementById("ghUser").value.trim();
  if(!username){ alert("Enter a GitHub username."); return; }
  state.github.username = username;
  state.github.error = "";
  const btn = event.target;
  btn.textContent = "Fetching…"; btn.disabled = true;
  try{
    const uRes = await fetch(`https://api.github.com/users/${encodeURIComponent(username)}`);
    if(!uRes.ok) throw new Error(uRes.status===404 ? "That GitHub username doesn't exist." : "GitHub API request failed.");
    const uData = await uRes.json();
    const rRes = await fetch(`https://api.github.com/users/${encodeURIComponent(username)}/repos?per_page=100`);
    const repos = rRes.ok ? await rRes.json() : [];
    const langCounts = {};
    let totalStars = 0, activeRepos = 0;
    const cutoff = Date.now() - 1000*60*60*24*180;
    repos.forEach(r=>{
      if(r.language) langCounts[r.language] = (langCounts[r.language]||0)+1;
      totalStars += r.stargazers_count || 0;
      if(new Date(r.pushed_at).getTime() > cutoff) activeRepos++;
    });
    const languages = Object.entries(langCounts).sort((a,b)=>b[1]-a[1]).map(([l,c])=>({l,c}));
    state.github = {
      username, loaded:true, error:"",
      data:{ repoCount: repos.length, activeRepos, totalStars, languages, followers: uData.followers, bio: uData.bio, avatar: uData.avatar_url, name: uData.name }
    };
  }catch(e){
    state.github.error = e.message.includes("Failed to fetch")
      ? "Couldn't reach GitHub from this browser (network/CORS). Try again, or check your connection."
      : e.message;
    state.github.loaded = false;
  }
  renderGithub();
}
function renderGithubResults(){
  const d = state.github.data;
  const score = computeGithubScore(state.github);
  return `
    <div class="grid3">
      <div class="panel stat"><div class="n mono">${d.repoCount}</div><div class="l">Public repos</div></div>
      <div class="panel stat"><div class="n mono">${d.activeRepos}</div><div class="l">Active in last 180 days</div></div>
      <div class="panel stat"><div class="n mono">${d.totalStars}</div><div class="l">Total stars</div></div>
    </div>
    <div class="panel">
      <h3>Language footprint</h3>
      ${d.languages.length ? d.languages.map(x=>`
        <div style="margin-bottom:9px;">
          <div style="display:flex; justify-content:space-between; font-size:12.5px;"><span>${x.l}</span><span class="mono">${x.c} repo${x.c>1?'s':''}</span></div>
          <div class="bar-track"><div class="bar-fill" style="width:${Math.min(x.c/d.repoCount*100,100)}%;"></div></div>
        </div>`).join("") : `<div class="empty">No language data on public repos.</div>`}
    </div>
    <div class="panel">
      <h3>GitHub score</h3>
      <div class="stat"><div class="n mono">${score}/100</div><div class="l">Weighted on repo count, recent activity, stars, and language spread</div></div>
    </div>
  `;
}

/* ---------------- DSA TRACKER ---------------- */
if(!state.dsaPlan) state.dsaPlan = {note:null, loading:false, error:""};

// The target is computed live from the student's own data — CGPA, resume
// gaps, interview performance, GitHub activity, and progress already logged —
// instead of a flat number per track.
function computeDynamicDSATarget(){
  let base = TRACKS[state.track].dsaTarget;
  if(state.resume.analyzed) base += state.resume.gaps.length * 8;
  if(state.cgpa && state.cgpa < 6) base += 20;
  if(state.interview.session.length >= 2 && state.interview.score < 50) base += 15;
  if(state.github.loaded && state.github.data.activeRepos >= 3) base -= 10;
  const solved = totalDSACount();
  if(solved > base) base = Math.ceil(solved * 1.15); // target keeps pace as they progress
  return Math.max(50, Math.min(base, 400));
}
// Per-topic targets aren't an even split either — topics the student has
// logged the least get a bigger share of the remaining target.
function computeTopicTargets(target){
  const solved = totalDSACount();
  const remaining = Math.max(target - solved, DSA_TOPICS.length);
  const weights = DSA_TOPICS.map(t => 1 / (1 + state.dsa[t]));
  const sumW = weights.reduce((a,b)=>a+b,0);
  const out = {};
  DSA_TOPICS.forEach((t,i)=>{ out[t] = Math.round(state.dsa[t] + remaining * weights[i] / sumW); });
  return out;
}

function renderDSA(){
  const target = computeDynamicDSATarget();
  const total = totalDSACount();
  const topicTargets = computeTopicTargets(target);
  const dp = state.dsaPlan;
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Practice log</div>
      <h1 class="serif">DSA progress tracker</h1>
      <p>Target for you right now: <b style="color:var(--text-hi)">${target} problems</b> — recalculated from your CGPA, resume gaps, interview results, GitHub activity, and what you've already logged below, not a flat track number.</p>
    </div>
    <div class="panel">
      <div class="stat" style="max-width:260px;"><div class="n mono">${total}/${target}</div><div class="l">Total solved</div></div>
      <div class="bar-track" style="margin-top:14px;"><div class="bar-fill" style="width:${Math.min(total/target*100,100)}%; background:var(--teal);"></div></div>
    </div>
    <div class="panel">
      <h3>By topic — weighted toward what you haven't logged yet</h3>
      ${DSA_TOPICS.map(t=>`
        <div style="display:flex; align-items:center; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--line);">
          <div style="flex:1;">
            <div style="font-size:13.5px; font-weight:500; display:flex; justify-content:space-between; max-width:280px;"><span>${t}</span><span class="mono" style="color:var(--text-mid); font-size:12px;">${state.dsa[t]}/${topicTargets[t]}</span></div>
            <div class="bar-track" style="max-width:280px;"><div class="bar-fill" style="width:${Math.min(state.dsa[t]/topicTargets[t]*100,100)}%;"></div></div>
          </div>
          <div style="display:flex; align-items:center; gap:10px; margin-left:16px;">
            <button class="btn btn-sm" onclick="bumpDSA('${t}',-1)">−</button>
            <span class="mono" style="min-width:24px; text-align:center;">${state.dsa[t]}</span>
            <button class="btn btn-sm" onclick="bumpDSA('${t}',1)">+</button>
          </div>
        </div>`).join("")}
    </div>
    <div class="panel">
      <h3>Why this target</h3>
      <button class="btn" ${dp.loading?'disabled':''} onclick="explainDSATarget()">${dp.loading ? "Analyzing your data…" : "Ask AI to explain my target"}</button>
      ${dp.error ? `<div class="err">${dp.error}</div>` : ""}
      ${dp.note ? `<div class="qa-fb" style="margin-top:12px; white-space:pre-wrap;">${dp.note}</div>` : ""}
    </div>
  `;
}
function bumpDSA(topic, delta){
  state.dsa[topic] = Math.max(0, state.dsa[topic] + delta);
  renderDSA();
}
async function explainDSATarget(){
  const dp = state.dsaPlan;
  dp.loading = true; dp.error = ""; renderDSA();
  try{
    const target = computeDynamicDSATarget();
    const system = "You are Athena, an AI placement mentor. In 2-3 short sentences, explain why this specific DSA problem-count target "
      + "was set for this student, referencing their actual numbers below, and name the 1-2 topics they should prioritize first. Plain text, no markdown.";
    const user = `Track: ${TRACKS[state.track].label}. Computed target: ${target}. CGPA: ${state.cgpa}. `
      + `Resume skill gaps: ${state.resume.analyzed ? (state.resume.gaps.join(", ") || "none") : "resume not analyzed"}. `
      + `Interview average: ${state.interview.score}/100 over ${state.interview.session.length} questions. `
      + `GitHub active repos: ${state.github.loaded ? state.github.data.activeRepos : "not connected"}. `
      + `DSA logged by topic: ${JSON.stringify(state.dsa)}. Total solved: ${totalDSACount()}.`;
    dp.note = await callClaude(user, system, 250);
  }catch(e){
    dp.error = "Couldn't reach the AI mentor (" + e.message + ").";
  }
  dp.loading = false;
  renderDSA();
}

/* ---------------- ROADMAP ---------------- */
if(!state.roadmap) state.roadmap = {ai:null, loading:false, error:""};

function renderRoadmap(){
  const trackReq = TRACKS[state.track].req;
  const known = new Set(state.resume.found.map(s=>s.toLowerCase()));
  const gaps = trackReq.filter(s=>!known.has(s.toLowerCase()));
  const dsaGap = Math.max(computeDynamicDSATarget() - totalDSACount(), 0);
  const weeks = buildRoadmap(gaps, dsaGap);
  const rm = state.roadmap;
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Generated plan</div>
      <h1 class="serif">Your learning roadmap</h1>
      <p>The phases below are computed live from your actual resume gaps, DSA log, and certificates. For a written, personalized plan, ask Claude to expand on it.</p>
    </div>
    <div class="panel">
      <button class="btn btn-primary" ${rm.loading?'disabled':''} onclick="generateAIRoadmap()">${rm.loading ? "Writing your plan…" : "Generate personalized write-up with AI"}</button>
      ${rm.error ? `<div class="err">${rm.error}</div>` : ""}
      ${rm.ai ? `<div class="qa-fb" style="margin-top:14px; white-space:pre-wrap;">${rm.ai}</div>` : ""}
    </div>
    ${weeks.map((w,i)=>`
      <div class="panel">
        <h3>${w.title}</h3>
        ${w.items.map(it=>`<div style="padding:7px 0; border-bottom:1px solid var(--line); font-size:13.5px; color:var(--text-mid); display:flex; justify-content:space-between;"><span>${it.task}</span><span class="badge">${it.tag}</span></div>`).join("")}
      </div>
    `).join("")}
  `;
}
async function generateAIRoadmap(){
  const rm = state.roadmap;
  rm.loading = true; rm.error = ""; renderRoadmap();
  try{
    const system = "You are Athena, an AI placement mentor. Write a short, specific, encouraging weekly study plan (max 200 words, plain text, no markdown headers) "
      + "for a fresher based on their real profile data below. Be concrete — name actual topics/skills from the data, not generic advice.";
    const user = `Track: ${TRACKS[state.track].label}\n`
      + `Resume score: ${computeResumeScore(state.resume)}/100. Skills found: ${state.resume.found.join(", ") || "none"}. `
      + `Skill gaps: ${state.resume.gaps ? state.resume.gaps.join(", ") : "unknown, resume not analyzed yet"}.\n`
      + `GitHub: ${state.github.loaded ? state.github.data.repoCount + " repos, " + state.github.data.activeRepos + " active recently" : "not connected"}.\n`
      + `DSA problems solved: ${totalDSACount()} of your personalized ${computeDynamicDSATarget()} target, by topic: ${JSON.stringify(state.dsa)}.\n`
      + `Certificates: ${state.certs.map(c=>c.name).join(", ") || "none"}.\n`
      + `Mock interview average score: ${state.interview.score}/100 across ${state.interview.session.length} questions.\n`
      + `Overall readiness index: ${computePRI()}/100.\n\nWrite the plan.`;
    rm.ai = await callClaude(user, system, 500);
  }catch(e){
    rm.error = "Couldn't generate the AI write-up (" + e.message + "). The computed plan below is still accurate.";
  }
  rm.loading = false;
  renderRoadmap();
}
function buildRoadmap(gaps, dsaGap){
  const weeks = [];
  if(gaps.length){
    weeks.push({title:"Phase 1 — Close skill gaps", items: gaps.slice(0,5).map(g=>({task:`Build a small project using ${g}`, tag:"Skill"}))});
  }
  if(dsaGap>0){
    const perWeek = Math.max(Math.round(dsaGap/6),3);
    weeks.push({title:"Phase 2 — DSA sprint", items:[
      {task:`Solve ~${perWeek} problems/week across weak topics until you hit the target`, tag:"DSA"},
      {task:"Focus one week each on Arrays/Strings, Trees, Graphs, and DP", tag:"DSA"},
      {task:"Re-attempt any topic where your logged count is under 10", tag:"Review"}
    ]});
  }
  weeks.push({title:"Phase 3 — Interview & profile polish", items:[
    {task:"Run at least 3 mock interviews in your track and act on the feedback", tag:"Interview"},
    {task:"Push 1–2 GitHub projects with clear READMEs and recent commits", tag:"GitHub"},
    {task: state.resume.suggestions.length ? "Apply the resume suggestions from the Resume panel" : "Keep resume bullets metric-driven", tag:"Resume"}
  ]});
  if(state.certs.length===0){
    weeks.push({title:"Optional — Credibility boost", items:[{task:"Add one relevant certificate (course, hackathon, or badge)", tag:"Certs"}]});
  }
  return weeks;
}

/* ---------------- MOCK INTERVIEW (live AI interviewer) ---------------- */
// state.interview = { session:[{question,type,answer,feedback}], loading:false, error:"", score:0 }
if(!state.interview.session) state.interview.session = [];

function interviewContextSummary(){
  const gaps = state.resume.analyzed ? state.resume.gaps : TRACKS[state.track].req;
  const skills = state.resume.analyzed ? state.resume.found : [];
  return `Track: ${TRACKS[state.track].label}. Candidate is a fresher preparing for campus placement. `
    + `Detected resume skills: ${skills.length ? skills.join(", ") : "none yet"}. `
    + `Skill gaps versus this track: ${gaps.length ? gaps.join(", ") : "none"}. `
    + `DSA problems logged: ${totalDSACount()}.`;
}

function renderInterview(){
  const iv = state.interview;
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Practice room — live AI interviewer</div>
      <h1 class="serif">Mock interview</h1>
      <p>Each question is generated by Claude based on your actual profile (track, resume skills, and gaps), and every answer gets real AI feedback — not a canned script.</p>
    </div>
    <div class="panel">
      <button class="btn btn-primary" ${iv.loading?'disabled':''} onclick="startOrNextQuestion()">
        ${iv.loading ? "Thinking…" : (iv.session.length ? "Ask next question" : "Start interview")}
      </button>
      ${iv.error ? `<div class="err">${iv.error}</div>` : ""}
    </div>
    ${iv.session.map((qa,i)=>renderQABlock(qa,i)).join("")}
    <div class="panel">
      <h3>Interview score</h3>
      <div class="stat"><div class="n mono">${iv.score}/100</div><div class="l">Average AI-graded score across answered questions</div></div>
    </div>
  `;
}

function renderQABlock(qa,i){
  return `
    <div class="panel qa-block">
      <div class="qa-q">${i+1}. ${qa.question} <span class="badge" style="margin-left:6px;">${qa.type}</span></div>
      <textarea id="ans${i}" rows="4" placeholder="Type your answer...">${qa.answer || ""}</textarea>
      <div style="margin-top:8px;"><button class="btn btn-sm btn-primary" ${qa.loading?'disabled':''} onclick="submitAnswer(${i})">${qa.loading ? "Grading…" : "Get AI feedback"}</button></div>
      ${qa.feedback ? `<div class="qa-fb">
        <div><b style="color:var(--gold)">Score: ${qa.feedback.score}/10</b></div>
        <div style="margin-top:6px;"><b>Strengths:</b> ${qa.feedback.strengths}</div>
        <div style="margin-top:6px;"><b>To improve:</b> ${qa.feedback.improve}</div>
        ${qa.feedback.model_answer_tip ? `<div style="margin-top:6px;"><b>Tip:</b> ${qa.feedback.model_answer_tip}</div>` : ""}
      </div>` : (qa.fbError ? `<div class="err">${qa.fbError}</div>` : "")}
    </div>
  `;
}

async function startOrNextQuestion(){
  const iv = state.interview;
  iv.loading = true; iv.error = ""; renderInterview();
  try{
    const prior = iv.session.map(q=>`Q: ${q.question}\nA: ${q.answer||"(not answered)"}`).join("\n\n");
    const system = "You are Athena, an experienced technical interviewer running a campus placement mock interview. "
      + "Ask exactly one clear, focused interview question (technical or behavioral) appropriate for a fresher candidate. "
      + "Vary question type and build on weak areas from prior answers if any are given. "
      + "Reply with ONLY the question text — no preamble, no numbering, no quotation marks.";
    const user = interviewContextSummary() + (prior ? `\n\nQuestions asked so far:\n${prior}` : "") + "\n\nAsk the next interview question now.";
    const questionText = await callClaude(user, system, 200);
    const type = /tell me about a time|describe a situation|disagree|conflict|deadline|failure|mistake/i.test(questionText) ? "behavioral" : "technical";
    iv.session.push({question: questionText.trim(), type, answer:"", feedback:null});
  }catch(e){
    iv.error = "Couldn't reach the AI interviewer (" + e.message + "). Check your connection and try again.";
  }
  iv.loading = false;
  renderInterview();
}

async function submitAnswer(i){
  const iv = state.interview;
  const qa = iv.session[i];
  const text = document.getElementById(`ans${i}`).value.trim();
  if(text.length < 5){ alert("Write an answer first."); return; }
  qa.answer = text; qa.loading = true; qa.fbError = ""; renderInterview();
  try{
    const system = "You are Athena, a strict but encouraging technical interviewer grading one answer from a campus-placement mock interview. "
      + "Respond with ONLY valid JSON in this exact shape, no markdown fences: "
      + '{"score": <integer 0-10>, "strengths": "<one sentence>", "improve": "<one sentence, specific>", "model_answer_tip": "<one short actionable tip>"}';
    const user = `${interviewContextSummary()}\n\nQuestion asked: ${qa.question}\nCandidate's answer: ${text}\n\nGrade this answer.`;
    const raw = await callClaude(user, system, 400);
    qa.feedback = extractJson(raw);
  }catch(e){
    qa.fbError = "Couldn't get AI feedback (" + e.message + "). Try again.";
  }
  qa.loading = false;
  const graded = iv.session.filter(q=>q.feedback);
  iv.score = graded.length ? Math.round(graded.reduce((a,q)=>a+q.feedback.score,0)/graded.length*10) : 0;
  renderInterview();
}

/* ---------------- CERTIFICATES ---------------- */
function renderCerts(){
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Credential manager</div>
      <h1 class="serif">Certificates</h1>
      <p>Log courses, hackathons, and badges. These feed into your profile completeness score and eligibility checks.</p>
    </div>
    <div class="panel">
      <div class="grid2">
        <div class="field"><label>Certificate name</label><input id="cName" placeholder="AWS Cloud Practitioner"></div>
        <div class="field"><label>Issuer</label><input id="cIssuer" placeholder="Amazon Web Services"></div>
        <div class="field"><label>Date</label><input id="cDate" type="date"></div>
        <div class="field"><label>Category</label>
          <select id="cCat"><option>Cloud/DevOps</option><option>Web</option><option>Data/ML</option><option>CS Core</option><option>Other</option></select>
        </div>
      </div>
      <button class="btn btn-primary" onclick="addCert()">Add certificate</button>
    </div>
    <div class="panel">
      <h3>Your certificates (${state.certs.length})</h3>
      ${state.certs.length ? `<table><tr><th>Name</th><th>Issuer</th><th>Date</th><th>Category</th><th></th></tr>
        ${state.certs.map((c,i)=>`<tr><td>${c.name}</td><td>${c.issuer||"—"}</td><td>${c.date||"—"}</td><td><span class="badge teal">${c.category}</span></td><td><button class="icon-x" onclick="delCert(${i})">✕</button></td></tr>`).join("")}
      </table>` : `<div class="empty">No certificates logged yet.</div>`}
    </div>
  `;
}
function addCert(){
  const name = document.getElementById("cName").value.trim();
  if(!name){ alert("Enter a certificate name."); return; }
  state.certs.push({
    name, issuer: document.getElementById("cIssuer").value.trim(),
    date: document.getElementById("cDate").value, category: document.getElementById("cCat").value
  });
  renderCerts();
}
function delCert(i){ state.certs.splice(i,1); renderCerts(); }

/* ---------------- ELIGIBILITY ---------------- */
function renderEligibility(){
  const pri = computePRI();
  const dsa = totalDSACount();
  const known = new Set(state.resume.found.map(s=>s.toLowerCase()));
  document.getElementById("main").innerHTML = `
    <div class="pagehead">
      <div class="eyebrow">Rule-based screen</div>
      <h1 class="serif">Company eligibility checker</h1>
      <p>Checks your current stats against sample hiring bars. Adjust CGPA/backlogs and this recalculates live.</p>
    </div>
    <div class="panel grid2">
      <div class="field"><label>CGPA</label><input id="cgpaIn" type="number" step="0.1" min="0" max="10" value="${state.cgpa}" oninput="updateElig()"></div>
      <div class="field"><label>Active backlogs</label><input id="backIn" type="number" min="0" value="${state.backlogs}" oninput="updateElig()"></div>
    </div>
    <div class="panel">
      <div class="grid3" style="margin-bottom:14px;">
        <div class="stat"><div class="n mono">${state.cgpa}</div><div class="l">CGPA</div></div>
        <div class="stat"><div class="n mono">${dsa}</div><div class="l">DSA solved</div></div>
        <div class="stat"><div class="n mono">${pri}</div><div class="l">Readiness index</div></div>
      </div>
      ${COMPANIES.map(c=>{
        const reasons = [];
        if(state.cgpa < c.minCGPA) reasons.push(`CGPA below ${c.minCGPA}`);
        if(dsa < c.minDSA) reasons.push(`Needs ${c.minDSA}+ DSA problems (you have ${dsa})`);
        if(pri < c.minPRI) reasons.push(`Readiness index below ${c.minPRI}`);
        if(state.backlogs > c.backlogsOK) reasons.push(`Too many active backlogs (max ${c.backlogsOK})`);
        const hasSkill = c.skillsAny.some(s=>known.has(s));
        if(!hasSkill) reasons.push(`No detected skill from: ${c.skillsAny.join(", ")}`);
        const eligible = reasons.length===0;
        return `<div class="company-row">
          <div><div class="company-name">${c.name}</div><div class="company-meta">${c.tier} · min CGPA ${c.minCGPA} · min ${c.minDSA} DSA · min PRI ${c.minPRI}</div>
          ${!eligible ? `<div class="company-meta" style="color:var(--coral); margin-top:3px;">${reasons.join(" · ")}</div>` : ""}
          </div>
          <span class="badge ${eligible?'gold':'coral'}">${eligible?"Eligible":"Not yet"}</span>
        </div>`;
      }).join("")}
    </div>
  `;
}
function updateElig(){
  state.cgpa = parseFloat(document.getElementById("cgpaIn").value) || 0;
  state.backlogs = parseInt(document.getElementById("backIn").value) || 0;
  renderEligibility();
}

/* ---------------- init ---------------- */
renderAuth();
