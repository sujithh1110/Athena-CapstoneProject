# ATHENA — separated frontend and backend

This folder contains the original browser prototype split into frontend files, plus a completed starter backend scaffold and local Docker setup.

## Folder structure

```text
ATHENA/
├── frontend/
│   ├── index.html
│   ├── styles.css
│   ├── app.js
│   ├── Dockerfile
│   └── nginx.conf
├── backend/
│   ├── main.py
│   ├── models.py
│   ├── requirements.txt
│   └── Dockerfile
├── docker-compose.yml
├── .env.example
├── .gitignore
└── README.md
```

## Option A — Run everything with Docker Desktop

1. Install and start Docker Desktop.
2. In this project folder, copy `.env.example` to `.env`.
3. Change `POSTGRES_PASSWORD` in `.env` to a strong local password.
4. Open PowerShell in this folder and run:

   ```powershell
   docker compose up --build
   ```

5. Open the frontend at `http://localhost:8080`.
6. Open the backend API docs at `http://localhost:8000/docs`.
7. Check backend health at `http://localhost:8000/health`.

Stop the services with `Ctrl+C`, then run `docker compose down`. To also delete the local database volume, use `docker compose down -v` (this permanently deletes the local database data).

## Option B — Run backend locally

You need Python 3.10+ and a running PostgreSQL database. Set `DATABASE_URL` to your database connection string, then:

```powershell
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --reload
```

The API will be available at `http://localhost:8000`; interactive docs are at `http://localhost:8000/docs`.

## Run frontend without Docker

Open `frontend/index.html` in a browser, or serve the folder with a local static server such as VS Code Live Server. The page uses external CDN resources for fonts, PDF.js and EmailJS, so those parts need internet access.

## Backend models supplied

`backend/models.py` defines SQLAlchemy tables for:

- `Student` — name, email, password hash, career track and creation time.
- `Resume` — uploaded/extracted resume text and analysis score.
- `Certificate` — certificate name, issuer, category and issue date.
- `DSALog` — per-student DSA topic counts.

The API creates these tables on startup for this starter project. For a production deployment, use Alembic migrations instead of automatic `create_all`.

## API routes

- `POST /auth/signup`
- `POST /auth/login`
- `POST /resume/analyze`
- `POST /github/analyze`
- `POST /dsa/log`
- `GET /dsa/summary/{student_id}`
- `GET /health`

## Important limitations — read before presenting as production-ready

- This is a starter implementation, not a production-ready placement platform.
- The separated browser frontend is the original client-side prototype. Its current interactions are not all wired to these backend routes; frontend/backend integration remains a separate task.
- Login currently returns a development token, not a signed JWT. Passwords are hashed with PBKDF2, but protected-route authorization, JWT signing/expiry and rate limiting still need to be implemented before deployment.
- The resume analyzer is a simple keyword heuristic, not a semantic AI resume evaluator.
- The GitHub score is a simple public-repository heuristic and does not assess code quality or prove authorship.
- The AI interview/roadmap feature in the browser code needs secure server-side API integration. Do not put private provider API keys in frontend JavaScript.
- The frontend EmailJS configuration still needs the user's own EmailJS service/template/public key if that browser-side feature is used. Backend SMTP is optional and disabled until configured.
- Company eligibility and any external platform sync should be verified against real requirements before being used for decisions.
- Restrict CORS, use HTTPS, configure secrets securely, add tests, authorization, database migrations, backups and monitoring before public deployment.

## Original project material

`README_original.md` preserves the README from the supplied ZIP. `athena.html` is also retained at the project root as the original single-file frontend source for reference.
